package uniandes.dpoo.aerolinea.persistencia;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.tiquetes;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

/**
 * Esta clase implementa la persistencia de los tiquetes en formato JSON.
 */
public class PersistenciaTiquetesJson implements IPersistenciaTiquetes {

    public static final String NOMBRE_CLIENTE = "nombre";
    public static final String TIPO_CLIENTE = "tipoCliente";
    public static final String CLIENTE = "cliente";
    public static final String USADO = "usado";
    public static final String TARIFA = "tarifa";
    public static final String CODIGO_TIQUETE = "codigoTiquete";
    public static final String FECHA = "fecha";
    public static final String CODIGO_RUTA = "codigoRuta";

    public void cargarTiquetes(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {

        String contenido = new String(Files.readAllBytes(Paths.get(archivo)));
        JSONArray tiquetesJson = new JSONArray(contenido);

        for (int i = 0; i < tiquetesJson.length(); i++) {
            JSONObject tiqueteJson = tiquetesJson.getJSONObject(i);
                        
            String nombreCliente = tiqueteJson.getString(NOMBRE_CLIENTE);
            String tipoCliente = tiqueteJson.getString(TIPO_CLIENTE);
            String codigoTiquete = tiqueteJson.getString(CODIGO_TIQUETE);
            int tarifa = tiqueteJson.getInt(TARIFA);
            String codigoRuta = tiqueteJson.getString(CODIGO_RUTA);
            String fecha = tiqueteJson.getString(FECHA);
            boolean usado = tiqueteJson.getBoolean(USADO);
         
            Cliente cliente = aerolinea.getCliente(nombreCliente);
            if (cliente == null) {
                throw new InformacionInconsistenteException("Cliente no encontrado: " + nombreCliente);
            }
            
            Tiquete tiquete = new Tiquete(codigoTiquete, aerolinea.getVuelo(codigoRuta, fecha), cliente, tarifa);
            if (usado) {
                tiquete.marcarComoUsado();
            }          
            aerolinea.agregarTiquete(tiquete);
        }
    }
    public void salvarTiquetes(String archivo, Aerolinea aerolinea) throws IOException {
        JSONArray tiquetesJson = new JSONArray();

        for (Tiquete tiquete : aerolinea.getTiquetes()) {
            JSONObject tiqueteJson = new JSONObject();
            tiqueteJson.put(NOMBRE_CLIENTE, tiquete.getCliente().getIdentificador());
            tiqueteJson.put(TIPO_CLIENTE, tiquete.getCliente().getTipoCliente());
            tiqueteJson.put(CODIGO_TIQUETE, tiquete.getCodigo());
            tiqueteJson.put(TARIFA, tiquete.getTarifa());
            tiqueteJson.put(CODIGO_RUTA, tiquete.getVuelo().getRuta().getCodigoRuta());
            tiqueteJson.put(FECHA, tiquete.getVuelo().getFecha());
            tiqueteJson.put(USADO, tiquete.esUsado());

            tiquetesJson.put(tiqueteJson);
        }
        try (FileWriter file = new FileWriter(archivo)) {
            file.write(tiquetesJson.toString());
        }
    }
}
