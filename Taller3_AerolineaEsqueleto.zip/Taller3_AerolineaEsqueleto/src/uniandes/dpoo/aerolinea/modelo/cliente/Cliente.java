package uniandes.dpoo.aerolinea.modelo.cliente;

public abstract class Cliente
{
	public Cliente() {
		
	}
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	
}