package uniandes.dpoo.aerolinea.modelo;

import java.util.ArrayList;
import java.util.Collection;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
    private String fecha;
    private Ruta ruta;
    private Avion avion;
    private Collection<Tiquete> tiquetes;

    public Vuelo(Ruta ruta, String fecha, Avion avion) {
        this.fecha = fecha;
        this.ruta = ruta;
        this.avion = avion;
        this.tiquetes = new ArrayList<>();
    }

    public Ruta getRuta() {
        return ruta;
    }

    public String getFecha() {
        return fecha;
    }

    public Avion getAvion() {
        return avion;
    }

    public Collection<Tiquete> getTiquetes() {
        return this.tiquetes;
    }

    public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
        int tiquetesVendidos = 0;

        for (int i = 0; i < cantidad; i++) {
    
            int tarifa = calculadora.calcularTarifa(this, cliente);
            Tiquete tiquete = new Tiquete("T" + (tiquetes.size() + 1), this, cliente, tarifa);
            tiquetes.add(tiquete);
            tiquetesVendidos++;
        }

        return tiquetesVendidos;
    }

    
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Vuelo)) {
            return false;
        }

        Vuelo otroVuelo = (Vuelo) obj;

        return this.ruta.equals(otroVuelo.getRuta()) &&
               this.avion.equals(otroVuelo.getAvion()) &&
               this.fecha.equals(otroVuelo.getFecha());
    }
}

